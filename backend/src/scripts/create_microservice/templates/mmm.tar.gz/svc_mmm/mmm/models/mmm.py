import tshared.models.base as base_models
from tortoise import fields, Model


class Option(Model, base_models.BaseModelOptions):
    class Meta:
        table = "mmm_options"
        unique_together = (('id_tenant', 'key'),)
        app = 'mmm'

