import uuid
import json
import bcrypt
import datetime
import base3.handlers
from base3 import http
import tortoise.timezone
from base3.core import Base
from base3.decorators import route, api
from tortoise.transactions import in_transaction

from .. import models
db_connection = 'conn_mmm'


@route('/about')
class MmmAboutHandler(Base):

    @api(auth=False)
    async def get(self):
        return {'service': 'mmm'}


@route('/options')
class MmmOptionsHandler(base3.handlers.BaseOptionsHandler):
    model_Option = models.Option
    db_connection = db_connection
