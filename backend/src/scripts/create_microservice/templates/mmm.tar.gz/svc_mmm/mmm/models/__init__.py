table_prefix = 'mmm_'

from .mmm import *
from .lookups import *
