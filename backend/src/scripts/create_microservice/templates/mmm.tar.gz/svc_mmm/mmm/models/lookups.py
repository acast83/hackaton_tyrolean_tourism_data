from tortoise import fields, timezone, Model
import tshared.models.base as base_models

# {{ lookup_model }}{# TEMPLATE PLACEHOLDER. DO NOT DELETE #}
